**User Usage and Data Policy**

Welcome to our AI STEM Tutor! Our goal is to provide students with effective assistance in Science, Technology, Engineering, and Mathematics (STEM) subjects. To ensure a safe and productive environment for everyone, please adhere to the following guidelines:

### Appropriate Use

* The AI Tutor is designed exclusively for educational assistance in STEM-related subjects, including mathematics, computer science, physics, chemistry, biology, engineering, and related fields.
* Users must avoid submitting or requesting content related to inappropriate, illegal, harmful, offensive, discriminatory, or sensitive social topics.

### Privacy and Personal Information

* Do not share private, personal, or sensitive information during interactions with the AI Tutor, including but not limited to your name, address, phone number, email address, passwords, or any identifiable information.
* Please be aware that your questions and responses will be processed through third-party AI providers, including OpenAI. We do not control these third-party providers’ handling of information beyond what is described in their respective privacy policies.

### Data Usage and Retention

* Questions, answers, and other interactions between users and the AI Tutor may be collected, stored, and analyzed to improve our services, user experience, and overall product performance.
* Collected data will be anonymized and aggregated whenever possible to protect user privacy.

### Acceptance of Policy

By using our AI STEM Tutor, you acknowledge and agree to this User Usage and Data Policy. If you do not agree to these terms, please discontinue using the application immediately.

Thank you for helping us maintain a supportive and effective educational environment!

