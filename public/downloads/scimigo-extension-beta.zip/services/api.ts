import type { SolveMode } from '@math-agents/types';
import eventBus, { EVENTS } from '../core/eventBus';
import { APP_CONFIG, API_ENDPOINTS } from '../utils/constants';
import { getAccessToken } from './auth';

interface StreamCallbacks {
  start?: (data: { model: string; conversationId?: string }) => void;
  delta?: (data: { content: string }) => void;
  plot?: (data: { plot_data: any }) => void;
  error?: (data: { error: string }) => void;
  end?: (data: { usage?: { total_tokens: number }; error?: string; metadata?: any }) => void;
}

interface SolveOptions {
  mode?: SolveMode;
  sessionContext?: any;
  history?: any[];
  conversationId?: string | null;
}

interface AudioReviewResponse {
  artifact_id: string;
  status: 'pending' | 'generating' | 'active' | 'failed';
  generation_params?: {
    audio_url?: string;
    duration_seconds?: number;
  };
}

export class ChromeExtensionApiClient {
  solveStream(
    message: string,
    callbacks: StreamCallbacks,
    onError: (error: Error) => void,
    options: SolveOptions = {}
  ) {
    // Generate a unique request ID
    const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    let hasStarted = false;
    let messageSubscription: string | null = null;
    let errorSubscription: string | null = null;

    // Set up cleanup function
    const cleanup = () => {
      if (messageSubscription) eventBus.unsubscribe(messageSubscription);
      if (errorSubscription) eventBus.unsubscribe(errorSubscription);
    };

    // Set up EventBus listeners BEFORE sending the request to avoid race conditions
    const messageHandler = (payload: any) => {
      
      if (!payload || (payload.responseId && payload.responseId !== requestId)) {
        return;
      }

      if (payload.conversationId && callbacks.start) {
        callbacks.start({ model: 'auto', conversationId: payload.conversationId });
      }

      if (callbacks.delta && payload.content) {
        callbacks.delta({ content: payload.content });
      }
      if (payload.isComplete && callbacks.end) {
        callbacks.end({
          usage: payload.usageStats ? { total_tokens: payload.usageStats.total_tokens } : undefined
        });
      }
    };

    const errorHandler = (payload: any) => {
      
      if (!payload || (payload.responseId && payload.responseId !== requestId)) {
        return;
      }
      
      // Check if this is a rate limit error (429)
      if (payload.status === 429 || payload.error?.status === 429) {
        // Rate limit modal will be shown by content script handler
        if (callbacks.error) {
          callbacks.error({ error: payload.message || 'Rate limit exceeded' });
        }
        if (callbacks.end) {
          callbacks.end({ error: payload.message || 'Rate limit exceeded' });
        }
        return;
      }
      
      if (callbacks.error) {
        callbacks.error({ error: payload.error?.message || 'Stream error occurred' });
      }
      if (callbacks.end) {
        callbacks.end({ error: payload.error?.message || 'Stream error occurred' });
      }
    };

    // Subscribe to EventBus events BEFORE sending the request
    // Subscribing to EventBus events
    messageSubscription = eventBus.subscribe(EVENTS.AI_MESSAGE, messageHandler);
    errorSubscription = eventBus.subscribe(EVENTS.STREAM_ERROR, errorHandler);
    // EventBus subscriptions created

    // Send message to background script using the existing chrome extension pattern
    const sendRequest = async () => {
      try {
        
        if (callbacks.start) {
          callbacks.start({ model: 'auto' });
          hasStarted = true;
        }

        // Use the existing chrome.runtime messaging system
        const messagePayload = {
          type: 'ASK_AI',
          question: message,
          isInitialPrompt: false,
          requestId: requestId,
          mode: options.mode || 'solve',
          history: options.history || [],
          conversationId: options.conversationId || null,
        };
        
        
        const response = await chrome.runtime.sendMessage(messagePayload);
        

        if (!response || !response.responseId) {
          throw new Error('No response ID received from background script');
        }

        return cleanup;

      } catch (error) {
        console.error('[API Client] Error sending request:', error);
        onError(error as Error);
        return cleanup;
      }
    };

    // Start the request
    sendRequest();

    return cleanup;
  }

  async getUserProfile(): Promise<any> {
    try {
      const token = await getAccessToken();
      const response = await fetch(
        `${APP_CONFIG.api.baseUrl}${API_ENDPOINTS.USER_PROFILE}`,
        {
          method: 'GET',
          headers: {
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          credentials: 'include', // Include cookies for session_id
        }
      );
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to fetch user profile');
      }
      return await response.json();
    } catch (error) {
      console.error('[API] getUserProfile failed:', error);
      throw error;
    }
  }

  async acceptUserAgreement(): Promise<void> {
    try {
      const token = await getAccessToken();
      // Token validation for agreement acceptance
      
      if (!token) {
        throw new Error('No authentication token available');
      }
      
      const url = `${APP_CONFIG.api.baseUrl}${API_ENDPOINTS.USER_AGREEMENT}`;
      // Making agreement acceptance request
      
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      };
      // Headers configured for request
      
      const response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify({}), // Empty body but still JSON
        credentials: 'include', // Include cookies for session_id
      });
      
      // Agreement response received
      
      if (!response.ok) {
        const errorText = await response.text();
        // Error response from agreement API
        
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { message: errorText };
        }
        
        const error = new Error(errorData.message || `Failed to accept user agreement (${response.status})`);
        (error as any).status = response.status;
        throw error;
      }
      
      // Agreement accepted successfully
    } catch (error) {
      console.error('[API] acceptUserAgreement failed:', error);
      throw error;
    }
  }

  async createAudioReview(conversationId: string): Promise<AudioReviewResponse> {
    try {
      const token = await getAccessToken();
      const response = await fetch(
        `${APP_CONFIG.api.baseUrl}${API_ENDPOINTS.AUDIO_REVIEW(conversationId)}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          credentials: 'include', // Include cookies for session_id
        }
      );
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to request audio review');
      }
      return await response.json();
    } catch (error) {
      console.error('[API] createAudioReview failed:', error);
      throw error;
    }
  }

  async getAudioReview(conversationId: string): Promise<AudioReviewResponse> {
    try {
      const token = await getAccessToken();
      const response = await fetch(
        `${APP_CONFIG.api.baseUrl}${API_ENDPOINTS.AUDIO_REVIEW(conversationId)}`,
        {
          method: 'GET',
          headers: {
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          credentials: 'include', // Include cookies for session_id
        }
      );
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to fetch audio review');
      }
      return await response.json();
    } catch (error) {
      console.error('[API] getAudioReview failed:', error);
      throw error;
    }
  }
}

export const apiClient = new ChromeExtensionApiClient();