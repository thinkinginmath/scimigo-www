import React, { useState, useEffect, useRef } from 'react';
import { renderMarkdownWithKatex } from '../../utils/markdownUtils';

interface HintMessageProps {
  hints: string[];
  onRequestSolution?: () => void;
  darkMode?: boolean;
  katexReady: boolean;
}

const HintMessage: React.FC<HintMessageProps> = ({ hints, onRequestSolution, darkMode = false, katexReady }) => {
  const [currentHintIndex, setCurrentHintIndex] = useState(0);
  const [displayedHints, setDisplayedHints] = useState<string[]>([]);
  const contentRefs = useRef<(HTMLDivElement | null)[]>([]);
  
  useEffect(() => {
    // Initialize with first hint
    if (hints.length > 0 && displayedHints.length === 0) {
      setDisplayedHints([hints[0]]);
    }
  }, [hints]);

  useEffect(() => {
    // Render markdown for each displayed hint
    displayedHints.forEach((hint, index) => {
      const ref = contentRefs.current[index];
      if (ref && katexReady) {
        const formattedHint = `**Hint ${index + 1}:** ${hint}`;
        renderMarkdownWithKatex(formattedHint, ref, katexReady, `hint-${index}`);
      }
    });
  }, [displayedHints, katexReady]);

  const handleNextHint = () => {
    if (currentHintIndex < hints.length - 1) {
      const nextIndex = currentHintIndex + 1;
      setCurrentHintIndex(nextIndex);
      setDisplayedHints([...displayedHints, hints[nextIndex]]);
    }
  };

  const handleShowAllHints = () => {
    setDisplayedHints([...hints]);
    setCurrentHintIndex(hints.length - 1);
  };

  const hasMoreHints = currentHintIndex < hints.length - 1;
  const remainingHints = hints.length - displayedHints.length;

  return (
    <div className="scimigo-hint-container">
      <div className="scimigo-hints-list">
        {displayedHints.map((hint, index) => (
          <div 
            key={index} 
            className="scimigo-hint-item"
            style={{
              marginBottom: '12px',
              padding: '12px',
              backgroundColor: darkMode ? '#3a3a3a' : '#f8f9fa',
              borderRadius: '8px',
              borderLeft: '4px solid #2196f3'
            }}
          >
            <div 
              ref={el => contentRefs.current[index] = el}
              className="scimigo-hint-content"
            />
          </div>
        ))}
      </div>
      
      <div className="scimigo-hint-actions" style={{ 
        marginTop: '16px', 
        display: 'flex', 
        gap: '8px',
        flexWrap: 'wrap'
      }}>
        {hasMoreHints && (
          <>
            <button
              onClick={handleNextHint}
              className="scimigo-hint-button scimigo-next-hint"
              style={{
                padding: '8px 16px',
                backgroundColor: '#2196f3',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '500'
              }}
            >
              Next Hint ({remainingHints} remaining)
            </button>
            
            {remainingHints > 1 && (
              <button
                onClick={handleShowAllHints}
                className="scimigo-hint-button scimigo-show-all"
                style={{
                  padding: '8px 16px',
                  backgroundColor: 'transparent',
                  color: '#2196f3',
                  border: '1px solid #2196f3',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '14px'
                }}
              >
                Show All Hints
              </button>
            )}
          </>
        )}
        
        {onRequestSolution && (
          <button
            onClick={onRequestSolution}
            className="scimigo-hint-button scimigo-solve"
            style={{
              padding: '8px 16px',
              backgroundColor: '#4caf50',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              marginLeft: hasMoreHints ? 'auto' : '0'
            }}
          >
            🎯 Solve Problem
          </button>
        )}
      </div>
    </div>
  );
};

export default HintMessage;