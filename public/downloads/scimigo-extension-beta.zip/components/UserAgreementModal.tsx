import React, { useEffect, useState } from 'react';
import { marked } from 'marked';

marked.setOptions({
  gfm: true,
  breaks: true,
});
import './UserAgreementModal.css';

interface Props {
  open: boolean;
  onAccept: () => void;
}

const UserAgreementModal: React.FC<Props> = ({ open, onAccept }) => {
  const [html, setHtml] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!open) return;
    const loadAgreement = async () => {
      setLoading(true);
      try {
        const res = await fetch(chrome.runtime.getURL('docs/user_agreement.md'));
        const text = await res.text();
        setHtml(marked.parse(text));
      } catch (err) {
        console.error('Failed to load agreement', err);
      } finally {
        setLoading(false);
      }
    };
    loadAgreement();
  }, [open]);

  if (!open) return null;

  return (
    <div className="agreement-modal-overlay">
      <div className="agreement-modal-container">
        <h2 className="agreement-modal-title">User Agreement</h2>
        {loading ? (
          <div className="agreement-modal-loading">
            <div className="spinner"></div>
            <p>Loading agreement...</p>
          </div>
        ) : (
          <>
            <div className="agreement-modal-content" dangerouslySetInnerHTML={{ __html: html }} />
            <button className="agreement-modal-button" onClick={onAccept}>
              Accept and Continue
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default UserAgreementModal;
